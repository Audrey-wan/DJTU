<template>
  <view class="container">
  <!-- 顶部展示区 -->
  <view class="header">
  <view class="header-top">
  <view class="lang-switch">
    <text class="logo-text">首都博物馆</text>
  <uni-icons type="language" size="10" color="#fff" />

  </view>
  <view class="header-right">
  <uni-icons type="more-filled" size="14" color="#fff" />
  </view>
  </view>
  </view>
  <!-- 轮播图区域 -->
  <swiper class="swiper" :indicator-dots="true" :autoplay="true" :interval="3000" :duration="1000" circular indicator-color="rgba(255, 255, 255, 0.6)" indicator-active-color="#FFD700">
  <swiper-item v-for="(item, index) in swiperList" :key="index">
  <image :src="item.image" mode="aspectFill" class="swiper-image" />
  <view class="swiper-info">
  <text class="swiper-title">{{ item.title }}</text>
  <text class="swiper-desc">{{ item.description }}</text>
  </view>
  </swiper-item>
  </swiper>
  <!-- 功能导航区 -->
  <view class="nav-grid">
  <view class="grid-item" v-for="(item, index) in navItems" :key="index">
  <image class="grid-icon" :src="item.icon" mode="aspectFit" />
  <text class="grid-text">{{ item.text }}</text>
  </view>
  </view>
  <!-- 馆藏精品区 -->
  <view class="collection">
  <view class="section-header">
  <text class="section-title">馆藏精品</text>
  <view class="view-all">
  <text class="view-all-text">全部</text>
  <uni-icons type="right" size="14" color="#666" />
  </view>
  </view>
  <scroll-view class="collection-scroll" scroll-x>
  <view class="collection-items">
  <view class="collection-item" v-for="(item, index) in collectionItems" :key="index">
  <image class="collection-image" :src="item.image" mode="aspectFit" />
  <text class="collection-name">{{ item.name }}</text>
  </view>
  </view>
  </scroll-view>
  </view>
  <!-- 游客互动区 -->
  <view class="interaction">
  <text class="section-title">游客互动</text>
  <view class="interaction-list">
  <view class="interaction-item" v-for="(item, index) in interactionItems" :key="index">
  <image class="interaction-image" :src="item.image" mode="aspectFill" />
  <text class="interaction-title">{{ item.title }}</text>
  </view>
  </view>
  </view>
  
  </view>
  </template>
  <script lang="ts" setup>
  import { ref } from 'vue';
  const headerImage = 'https://ai-public.mastergo.com/ai/img_res/468a168bc83f41d06d03e185d83017d1.jpg';
  import data from '../../data.json';
const swiperList = ref(data.swiperList);
  const navItems = ref(data.navItems);
  const collectionItems = ref(data.collectionItems);
  const interactionItems = ref(data.interactionItems);
 

  const handleTabClick = (clickedItem) => {
    // 重置所有tab的active状态
    tabItems.value.forEach(item => item.active = false);
    // 设置当前点击tab为激活状态
    clickedItem.active = true;
    // 跳转页面
    uni.switchTab({
      url: clickedItem.path
    });
  }
  </script>
  <style>
  page {
  height: 100%;
  }
  .container {
  min-height: 100%;
  background-color: #f9f5f2;
  display: flex;
  flex-direction: column;
  }
  .header {
  background-color: #8b0000;
  padding: 0 30rpx;
  padding-top: 88rpx;
  padding-bottom: 40rpx;
  }
  .header-top {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 24rpx;
  position: relative; /* 为绝对定位提供参考 */
  width: 100%; /* 确保容器占满父级宽度 */
  .lang-switch {
    text-align: center; /* 内部内容居中 */
  }
}

.museum-logo {
  display: flex;
  align-items: center;
}
  .logo-text {
  font-family: 'STXingkai', 'FZShuTi', 'KaiTi', serif; /* 华文行楷/方正舒体体现书法风格 */
  font-size: 60rpx;
  font-weight: normal; /* 书法字体通常自带笔锋，取消加粗 */
  color: #FFD700; /* 金色 */
  text-shadow: 0 2rpx 4rpx rgba(0,0,0,0.2);
  background: linear-gradient(45deg, #FFD700, #FFB300); /* 渐变效果 */
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}
  .lang-switch {
  display: flex;
  align-items: center;
  background: rgba(255, 255, 255, 0.2);
  border-radius: 30rpx;
  padding: 8rpx 20rpx;
  }
  .switch-text {
  color: #fff;
  font-size: 14px;
  margin-left: 8rpx;
  }
  .header-right {
    position: absolute;
    right: 30rpx; /* 保持右侧间距 */
    top: 50%;
    transform: translateY(-50%); /* 垂直居中 */
  }
  .header-content {
  position: relative;
  }
  .title {
  color: #fff;
  font-size: 32px;
  font-weight: normal; /* 书法字体通常自带笔锋，取消加粗 */
  margin-bottom: 30rpx;
  display: block;
  }
  .header-image {
  width: 400rpx;
  height: 400rpx;
  margin: 20rpx auto;
  display: block;
  }
  .cloud-decoration {
  width: 200rpx;
  height: 100rpx;
  position: absolute;
  right: 0;
  bottom: 0;
  }
  .swiper {
  width: 100%;
  height: 400rpx;
  margin: 20rpx 0;
  }
  
  .swiper-image {
  width: 100%;
  height: 100%;
  }
  
  .swiper-info {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: linear-gradient(transparent, rgba(0, 0, 0, 0.7));
  padding: 30rpx;
  }
  
  .swiper-title {
  font-size: 16px;
  color: #fff;
  font-weight: normal; /* 书法字体通常自带笔锋，取消加粗 */
  margin-bottom: 10rpx;
  display: block;
  }
  
  .swiper-desc {
  font-size: 14px;
  color: rgba(255, 255, 255, 0.8);
  display: block;
  }
  
  .nav-grid {
  display: flex;
  flex-wrap: wrap;
  padding: 30rpx;
  background: #fff;
  border-radius: 20rpx;
  margin: 20rpx 20rpx 0;
  position: relative;
  box-shadow: 0 4rpx 20rpx rgba(0, 0, 0, 0.1);
  }
  .grid-item {
  width: 20%;
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 30rpx;
  }
  .grid-icon {
  width: 80rpx;
  height: 80rpx;
  margin-bottom: 10rpx;
  }
  .grid-text {
  font-size: 12px;
  color: #333;
  }
  .collection {
  margin: 30rpx 20rpx;
  background: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
  }
  .section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30rpx;
  }
  .section-title {
  font-size: 18px;
  font-weight: normal; /* 书法字体通常自带笔锋，取消加粗 */
  color: #333;
  }
  .view-all {
  display: flex;
  align-items: center;
  }
  .view-all-text {
  font-size: 14px;
  color: #666;
  margin-right: 4rpx;
  }
  .collection-scroll {
  overflow: auto;
  }
  .collection-items {
  display: flex;
  padding: 10rpx 0;
  }
  .collection-item {
  margin-right: 30rpx;
  flex-shrink: 0;
  }
  .collection-image {
  width: 300rpx;
  height: 200rpx;
  border-radius: 10rpx;
  margin-bottom: 10rpx;
  }
  .collection-name {
  font-size: 14px;
  color: #333;
  display: block;
  }
  .interaction {
  margin: 0 20rpx 120rpx;
  background: #fff;
  border-radius: 20rpx;
  padding: 30rpx;
  }
  .interaction-list {
  display: flex;
  flex-wrap: wrap;
  margin: 0 -10rpx;
  }
  .interaction-item {
  width: calc(33.33% - 20rpx);
  margin: 10rpx;
  }
  .interaction-image {
  width: 100%;
  height: 200rpx;
  border-radius: 10rpx;
  margin-bottom: 10rpx;
  }
  .interaction-title {
  font-size: 14px;
  color: #333;
  display: block;
  }
  .tab-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100rpx;
  background-color: #8b0000;
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding-bottom: env(safe-area-inset-bottom);
  }
  .tab-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  }
  .tab-text {
  font-size: 12px;
  color: #f8e8e8;
  margin-top: 4rpx;
  }
  .tab-text.active {
  color: #FFD700;
  }
  </style>
  