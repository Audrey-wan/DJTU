<template>
    <view class="container">
    <!-- 顶部搜索区 -->
    <view class="search-area">
    <view class="search-box">
    <uni-icons type="search" size="20" color="#999"></uni-icons>
    <input class="search-input" type="text" placeholder="搜索博物馆、路线、文创" />
    </view>
    </view>
    
    <!-- 附近博物馆推荐 -->
    <view class="nearby-section">
    <view class="section-header">
    <text class="section-title">附近博物馆</text>
    <view class="more-btn">
    <text class="more-text">更多</text>
    <uni-icons type="right" size="14" color="#666"></uni-icons>
    </view>
    </view>
    <scroll-view scroll-x class="nearby-list">
    <view class="nearby-item" v-for="(item, index) in nearbyMuseums" :key="index">
    <image :src="item.imageUrl" mode="aspectFill" class="nearby-image" />
    <view class="nearby-info">
    <text class="nearby-name">{{ item.name }}</text>
    <text class="nearby-distance">{{ item.distance }}</text>
    <text class="nearby-desc">{{ item.description }}</text>
    </view>
    </view>
    </scroll-view>
    </view>
    
    <!-- 精品路线推荐 -->
    <view class="route-section">
    <view class="section-header">
    <text class="section-title">精品路线</text>
    <view class="more-btn">
    <text class="more-text">更多</text>
    <uni-icons type="right" size="14" color="#666"></uni-icons>
    </view>
    </view>
    <view class="route-list">
    <view class="route-item" v-for="(item, index) in recommendedRoutes" :key="index">
    <image :src="item.imageUrl" mode="aspectFill" class="route-image" />
    <view class="route-info">
    <view class="route-header">
    <text class="route-name">{{ item.name }}</text>
    <text class="route-duration">{{ item.duration }}</text>
    </view>
    <text class="route-desc">{{ item.description }}</text>
    <view class="route-tags">
    <text class="tag" v-for="(tag, tagIndex) in item.tags" :key="tagIndex">#{{ tag }}</text>
    </view>
    </view>
    </view>
    </view>
    </view>
    
    <!-- 文创好物 -->
    <view class="product-section">
    <view class="section-header">
    <text class="section-title">文创好物</text>
    <view class="more-btn">
    <text class="more-text">更多</text>
    <uni-icons type="right" size="14" color="#666"></uni-icons>
    </view>
    </view>
    <scroll-view scroll-x class="product-list">
    <view class="product-item" v-for="(item, index) in products" :key="index">
    <image :src="item.imageUrl" mode="aspectFill" class="product-image" />
    <view class="product-info">
    <text class="product-name">{{ item.name }}</text>
    <text class="product-price">¥{{ item.price }}</text>
    </view>
    </view>
    </scroll-view>
    </view>
    
    <!-- 精选主题展 -->
    <view class="theme-section">
    <view class="section-header">
    <text class="section-title">精选主题展</text>
    <view class="more-btn">
    <text class="more-text">更多</text>
    <uni-icons type="right" size="14" color="#666"></uni-icons>
    </view>
    </view>
    <view class="theme-list">
    <view class="theme-item" v-for="(item, index) in themeExhibitions" :key="index">
    <image :src="item.imageUrl" mode="aspectFill" class="theme-image" />
    <view class="theme-info">
    <text class="theme-name">{{ item.name }}</text>
    <text class="theme-date">{{ item.date }}</text>
    <text class="theme-desc">{{ item.description }}</text>
    </view>
    </view>
    </view>
    </view>
    
   
    </view>
    </template>
    <script lang="ts" setup>
    import { ref } from 'vue';
    const currentTab = ref(2); // 设置当前选中的tab为推荐页
    
    import data from '../../data.json';
const nearbyMuseums = ref(data.nearbyMuseums);
    
    const recommendedRoutes = ref(data.recommendedRoutes);
    
    const products = ref(data.products);
    
    const themeExhibitions = ref(data.themeExhibitions);
    
   
    </script>
    <style>
    page {
    height: 100%;
    }
    .container {
    min-height: 100%;
    background-color: #f9f5f2; /* 与首页统一的浅米色背景 */
    display: flex;
    flex-direction: column;
    padding: 20rpx;
  }
    .search-area {
    padding: 20rpx 30rpx;
    background-color: #8b0000;
    }
    .search-box {
    display: flex;
    align-items: center;
    background-color: #fff8eb; /* 暖色调搜索框 */
    padding: 16rpx 30rpx;
    border-radius: 32rpx;
    box-shadow: inset 0 2rpx 4rpx rgba(139,24,24,0.1); /* 内阴影增强质感 */
  }
    .search-input {
    flex: 1;
    margin-left: 20rpx;
    font-size: 14px;
    }
    .section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30rpx;
    }
    .section-title {
    font-size: 18px;
    font-weight: bold;
    color: #333;
    }
    .more-btn {
    display: flex;
    align-items: center;
    }
    .more-text {
    font-size: 14px;
    color: #666;
    margin-right: 8rpx;
    }
    /* 附近博物馆样式 */
    .nearby-section {
    margin-top: 20rpx;
    background-color: #fff;
    padding: 40rpx 30rpx;
    }
    .nearby-list {
    white-space: nowrap;
    }
    .nearby-item {
    display: inline-block;
    width: 480rpx;
    margin-right: 30rpx;
    border-radius: 24rpx; /* 更圆润的圆角 */
    overflow: hidden;
    background-color: #fff;
    box-shadow: 0 6rpx 18rpx rgba(139,24,24,0.1); /* 主色调阴影 */
    transition: transform 0.2s;
  }
  .nearby-item:hover {
    transform: translateY(-4rpx); /* 悬停微浮效果 */
  }
    .nearby-image {
    width: 480rpx;
    height: 320rpx;
    }
    .nearby-info {
    padding: 20rpx;
    }
    .nearby-name {
    font-size: 16px;
    font-weight: bold;
    color: #333;
    display: block;
    margin-bottom: 8rpx;
    }
    .nearby-distance {
    font-size: 12px;
    color: #8B1818;
    display: block;
    margin-bottom: 8rpx;
    }
    .nearby-desc {
    font-size: 14px;
    color: #666;
    display: block;
    }
    /* 路线推荐样式 */
    .route-section {
    margin-top: 20rpx;
    background-color: #fff;
    padding: 40rpx 30rpx;
    }
    .route-list {
    display: flex;
    flex-direction: column;
    gap: 30rpx;
    }
    .route-item {
    border-radius: 16rpx;
    overflow: hidden;
    background-color: #fff;
    box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.05);
    }
    .route-image {
    width: 690rpx;
    height: 360rpx;
    }
    .route-info {
    padding: 20rpx;
    }
    .route-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12rpx;
    }
    .route-name {
    font-size: 16px;
    font-weight: bold;
    color: #333;
    }
    .route-duration {
    font-size: 12px;
    color: #8B1818;
    background-color: rgba(139, 24, 24, 0.1);
    padding: 4rpx 16rpx;
    border-radius: 16rpx;
    }
    .route-desc {
    font-size: 14px;
    color: #666;
    line-height: 1.4;
    margin-bottom: 16rpx;
    display: block;
    }
    .route-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 16rpx;
    }
    /* 文创产品样式 */
    .product-section {
    margin-top: 20rpx;
    background-color: #fff;
    padding: 40rpx 30rpx;
    }
    .product-list {
    white-space: nowrap;
    }
    .product-item {
    display: inline-block;
    width: 240rpx;
    margin-right: 20rpx;
    border-radius: 12rpx;
    overflow: hidden;
    background-color: #fff;
    box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.05);
    }
    .product-image {
    width: 240rpx;
    height: 240rpx;
    }
    .product-info {
    padding: 16rpx;
    }
    .product-name {
    font-size: 14px;
    color: #333;
    display: block;
    margin-bottom: 8rpx;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    }
    .product-price {
    font-size: 16px;
    color: #8B1818;
    font-weight: bold;
    }
    /* 主题展览样式 */
    .theme-section {
    margin-top: 20rpx;
    background-color: #fff;
    padding: 40rpx 30rpx;
    margin-bottom: 120rpx;
    }
    .theme-list {
    display: flex;
    flex-direction: column;
    gap: 30rpx;
    }
    .theme-item {
    border-radius: 16rpx;
    overflow: hidden;
    background-color: #fff;
    box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.05);
    }
    .theme-image {
    width: 690rpx;
    height: 360rpx;
    }
    .theme-info {
    padding: 20rpx;
    }
    .theme-name {
    font-size: 16px;
    font-weight: bold;
    color: #333;
    margin-bottom: 8rpx;
    display: block;
    }
    .theme-date {
    font-size: 12px;
    color: #8B1818;
    margin-bottom: 12rpx;
    display: block;
    }
    .theme-desc {
    font-size: 14px;
    color: #666;
    line-height: 1.4;
    display: block;
    }
    .tag {
    font-size: 12px;
    color: #8B1818;
    background-color: rgba(139, 24, 24, 0.1);
    padding: 4rpx 16rpx;
    border-radius: 16rpx;
    }
    .tab-bar {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    height: 120rpx;
    background-color: #8B1818; /* 主色调背景 */
    display: flex;
    justify-content: space-around;
    align-items: center;
    border-top: 2rpx solid #fff;
    padding-bottom: env(safe-area-inset-bottom);
  }
  .tab-text {
    font-size: 14px;
    color: #f8e8e8;
    margin-top: 8rpx;
    font-family: 'KaiTi', serif; /* 楷体更符合文化主题 */
  }
  .tab-text.active {
    color: #FFD700; /* 金色激活态 */
    font-weight: bold;
  }
    .tab-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    }
    .tab-text {
    font-size: 12px;
    color: #666;
    margin-top: 6rpx;
    }
    .tab-text.active {
    color: #8B1818;
    }
    </style>
    