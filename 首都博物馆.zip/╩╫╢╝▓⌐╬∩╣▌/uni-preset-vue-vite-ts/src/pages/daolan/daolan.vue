<template>
  <view class="container">
  <!-- 顶部导航 -->
  <view class="header">
  <view class="logo">首都博物馆</view>
  <view class="nav-title">导览</view>
  <view class="lang-switch">
  <uni-button size="mini" type="default">EN</uni-button>
  </view>
  </view>
  <!-- 地图区域 -->
  <view class="map-container">
  <image class="map-image" :src="mapImageUrl" mode="aspectFill" />
  <view class="map-controls">
  <uni-icons type="plus" size="24" color="#666" @click="zoomIn" />
  <uni-icons type="minus" size="24" color="#666" @click="zoomOut" />
  </view>
  </view>
  <!-- 功能区 -->
  <view class="function-area">
  <scroll-view scroll-x class="exhibition-list">
  <view v-for="(item, index) in exhibitions" :key="index" class="exhibition-item" :class="{ active: currentExhibition === index }" @click="selectExhibition(index)">
  {{ item.name }}
  </view>
  </scroll-view>
  <view class="control-panel">
  <view class="control-item" @click="toggleAudio">
  <uni-icons :type="isAudioOn ? 'sound-filled' : 'sound'" size="24" color="#666" />
  <text class="control-text">语音导览</text>
  </view>
  <view class="control-item" @click="planRoute">
  <uni-icons type="map" size="24" color="#666" />
  <text class="control-text">路线规划</text>
  </view>
  <view class="control-item" @click="toggleFavorite">
  <uni-icons :type="isFavorite ? 'star-filled' : 'star'" size="24" color="#666" />
  <text class="control-text">收藏</text>
  </view>
  </view>
  </view>
  
  </view>
  </template>
  <script lang="ts" setup>
  import { ref } from 'vue';
  const mapImageUrl = 'https://ai-public.mastergo.com/ai/img_res/731cfee1c007ea85a4bb495af9be07ff.jpg';
  import data from '../../data.json';
const exhibitions = ref(data.exhibitions);
  const currentExhibition = ref(0);
  const currentLocation = ref('古代文明展厅');
  const progress = ref(25);
  const isAudioOn = ref(false);
  const isFavorite = ref(false);
  const selectExhibition = (index: number) => {
  currentExhibition.value = index;
  currentLocation.value = exhibitions.value[index].name;
  };
  const toggleAudio = () => {
  isAudioOn.value = !isAudioOn.value;
  };
  const toggleFavorite = () => {
  isFavorite.value = !isFavorite.value;
  };
  const planRoute = () => {
  // 路线规划功能
  };
  const zoomIn = () => {
  // 地图放大功能
  };
  const zoomOut = () => {
  // 地图缩小功能
  };
  
  </script>
  <style>
  page {
  height: 100%;
  }
  .container {
  height: 100%;
  display: flex;
  flex-direction: column;
  background-color: #f8f7f2;
  }
  .header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20rpx 30rpx;
  background-color: #fff;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
  flex-shrink: 0;
  }
  .logo {
  font-size: 16px;
  font-weight: bold;
  color: #333;
  }
  .nav-title {
  font-size: 16px;
  color: #666;
  }
  .map-container {
  position: relative;
  height: 800rpx;
  background-color: #fff;
  margin: 20rpx;
  border-radius: 16rpx;
  overflow: hidden;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  }
  .map-image {
  width: 100%;
  height: 100%;
  }
  .map-controls {
  position: absolute;
  right: 20rpx;
  bottom: 20rpx;
  background-color: rgba(255, 255, 255, 0.95);
  border-radius: 12rpx;
  padding: 16rpx;
  display: flex;
  flex-direction: column;
  gap: 16rpx;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  backdrop-filter: blur(8px);
  }
  .function-area {
  padding: 20rpx;
  background-color: #fff;
  margin: 0 20rpx;
  border-radius: 16rpx;
  }
  .exhibition-list {
  white-space: nowrap;
  margin-bottom: 30rpx;
  }
  .exhibition-item {
  display: inline-block;
  padding: 20rpx 40rpx;
  margin-right: 20rpx;
  background-color: #f5f5f5;
  border-radius: 30rpx;
  font-size: 14px;
  color: #666;
  }
  .exhibition-item.active {
  background-color: #4a6b8c;
  color: #fff;
  }
  .control-panel {
  display: flex;
  justify-content: space-around;
  padding: 20rpx 0;
  }
  .control-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10rpx;
  }
  .control-text {
  font-size: 12px;
  color: #666;
  }
  .footer {
  margin-top: auto;
  padding: 20rpx 30rpx;
  background-color: #fff;
  border-top: 1px solid #eee;
  }
  .progress {
  display: flex;
  justify-content: space-between;
  margin-bottom: 20rpx;
  font-size: 14px;
  color: #666;
  }
  .action-buttons {
  display: flex;
  justify-content: space-between;
  gap: 20rpx;
  }
  </style>
  