<template>
  <view class="page">
  <!-- 顶部区域 -->
  <view class="header">
  <text class="title">我的</text>
  <image class="logo" :src="logoUrl" mode="aspectFit" />
  </view>
  <!-- 用户信息区 -->
  <view class="user-card">
  <image class="avatar" :src="avatarUrl" mode="aspectFill" />
  <text class="username">微信用户</text>
  </view>
  <!-- 功能列表区 -->
  <view class="menu-list">
  <view class="menu-item" v-for="(item, index) in menuItems" :key="index" @tap="handleMenuClick(item)">
  <view class="menu-item-left">
  <uni-icons :type="item.icon" size="20" :color="themeColor" />
  <text class="menu-text">{{ item.text }}</text>
  </view>
  <uni-icons type="right" size="16" color="#999999" />
  </view>
  </view>
  <!-- 底部导航栏 -->
  <view class="tab-bar">
  <view class="tab-item" v-for="(tab, index) in tabItems" :key="index" @tap="handleTabClick(index)">
  <uni-icons :type="tab.icon" size="24" :color="currentTab === index ? themeColor : '#999999'" />
  <text class="tab-text" :class="{ active: currentTab === index }">{{ tab.text }}</text>
  </view>
  </view>
  </view>
  </template>
  <script lang="ts" setup>
  import { ref } from 'vue';
  const themeColor = '#8B0000';
  const currentTab = ref(4);

  // 用户头像URL
  const avatarUrl = 'https://ai-public.mastergo.com/ai/img_res/10c0f071d1e5e3f85e9d92068feccc89.jpg';
  // 菜单列表数据
  const menuItems = [
  { text: '门票订单', icon: 'ticket' },
  { text: '活动订单', icon: 'calendar' },
  { text: '讲座订单', icon: 'notification' },
  { text: '我的收藏', icon: 'star' },
  { text: '账户设置', icon: 'settings' },
  { text: '留言建议', icon: 'chat' }
  ];
  // 底部导航栏数据

  // 菜单项点击事件
  const handleMenuClick = (item: typeof menuItems[0]) => {
  console.log('Menu clicked:', item.text);
  };
  // 底部标签点击事件
  const handleTabClick = (index: number) => {
  currentTab.value = index;
  };
  </script>
  <style>
  page {
  height: 100%;
  }
  .page {
  min-height: 100%;
  background: linear-gradient(180deg, #F8F0E5 0%, #FFFFFF 100%);
  display: flex;
  flex-direction: column;
  }
  .header {
  position: relative;
  height: 280rpx;
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  padding: 0 40rpx 32rpx 40rpx;
  background: linear-gradient(135deg, #8B0000 0%, #A52A2A 100%);
  border-radius: 0 0 40rpx 40rpx;
  }
  .title {
  font-size: 24px;
  font-weight: 600;
  color: #FFFFFF;
  }
  .logo {
  width: 100rpx;
  height: 100rpx;
  filter: brightness(0) invert(1);
  }
  .user-card {
  margin: -60rpx 40rpx 0 40rpx;
  padding: 40rpx;
  background-color: #FFFFFF;
  border-radius: 24rpx;
  display: flex;
  align-items: center;
  box-shadow: 0 4rpx 20rpx rgba(0, 0, 0, 0.08);
  }
  .avatar {
  width: 140rpx;
  height: 140rpx;
  border-radius: 70rpx;
  margin-right: 32rpx;
  border: 4rpx solid #FFFFFF;
  box-shadow: 0 4rpx 16rpx rgba(0, 0, 0, 0.1);
  }
  .username {
  font-size: 18px;
  color: #333333;
  font-weight: 600;
  }
  .menu-list {
  margin: 40rpx;
  background-color: #FFFFFF;
  border-radius: 24rpx;
  box-shadow: 0 4rpx 20rpx rgba(0, 0, 0, 0.05);
  }
  .menu-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 36rpx 40rpx;
  position: relative;
  }
  .menu-item::after {
  content: '';
  position: absolute;
  left: 40rpx;
  right: 40rpx;
  bottom: 0;
  height: 1px;
  background-color: #F0F0F0;
  }
  .menu-item:last-child::after {
  display: none;
  }
  .menu-item-left {
  display: flex;
  align-items: center;
  }
  .menu-text {
  margin-left: 24rpx;
  font-size: 15px;
  color: #333333;
  font-weight: 500;
  }
  .tab-bar {
  height: 120rpx;
  background-color: #FFFFFF;
  display: flex;
  align-items: center;
  justify-content: space-around;
  border-top: 1px solid #F0F0F0;
  margin-top: auto;
  padding-bottom: env(safe-area-inset-bottom);
  box-shadow: 0 -4rpx 20rpx rgba(0, 0, 0, 0.05);
  }
  .tab-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 12rpx 24rpx;
  }
  .tab-text {
  margin-top: 8rpx;
  font-size: 12px;
  color: #999999;
  transition: color 0.3s ease;
  }
  .tab-text.active {
  color: #8B0000;
  font-weight: 500;
  }
  </style>
  