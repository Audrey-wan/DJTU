// 基础url
const baseUrl = 'http://localhost:3000';

// 请求
// 请求数据
export const request = (
	url,
	method,
	data
) => {
	return new Promise((resolve, reject) => {
		uni.request({
			url: baseUrl + url,
			method,
			data,
			// header: { Authorization: getToken() },
			success: (res) => {
				if (res.statusCode == 200) {
					resolve(res.data);
					console.log(res.data);
				} else if (res.statusCode == 405) {
					// 没有权限访问接口:跳转到登录界面
					// uni.navigateTo({ url: '/pages/login/index.vue' });
					reject(res);
				} else if (res.statusCode == 400) {
					uni.showToast({
						title: 'XXXX',
						icon: 'none',
						duration: 1000,
					});
					reject(res);
				} else if (res.statusCode == 401) {
					uni.showToast({
						title: 'XXXX',
						icon: 'none',
						duration: 1000,
					});
					reject(res);
				} else if (res.statusCode == 402) {
					uni.showToast({
						title: 'XXXX',
						icon: 'none',
						duration: 1000,
					});
					reject(res);
				} else if (res.statusCode == 403) {
					uni.showToast({
						title: 'XXXX',
						icon: 'none',
						duration: 1000,
					});
					reject(res);
				}
				else if (res.statusCode == 500) {
					uni.showToast({
						title: '参数缺失！！！',
						icon: 'none',
						duration: 1000,
					});
					reject(res);
				}
				else if (res.statusCode == 202) {
					uni.showToast({ title: res.data.msg, icon: 'none', duration: 1000 });
					reject(res);
				} else {
					uni.showToast({
						title: '服务器发生未知错误',
						icon: 'none',
						duration: 1000,
					});
					reject(res);
				}
			},
			fail: (err) => {
				uni.showToast({
					title: '服务器发生未知错误',
					icon: 'none',
					duration: 1000,
				});
				reject(err);
			},
		});
	});
}