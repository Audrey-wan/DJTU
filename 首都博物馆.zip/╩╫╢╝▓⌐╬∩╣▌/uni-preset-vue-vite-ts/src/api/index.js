import axios from 'axios';

// 配置json-server地址
const jsonServerUrl = 'http://localhost:3000';

// 获取首页数据
export const getHomeData = async () => {
  const res = await axios.get(`${jsonServerUrl}/homeData`);
  return res.data;
};

// 获取导览数据
export const getExhibitions = async () => {
  const res = await axios.get(`${jsonServerUrl}/exhibitions`);
  return res.data;
};

// 获取推荐数据
export const getRecommendData = async () => {
  const res = await axios.all([
    axios.get(`${jsonServerUrl}/nearbyMuseums`),
    axios.get(`${jsonServerUrl}/recommendedRoutes`),
    axios.get(`${jsonServerUrl}/products`),
    axios.get(`${jsonServerUrl}/themeExhibitions`)
  ]);
  return {
    nearbyMuseums: res[0].data,
    recommendedRoutes: res[1].data,
    products: res[2].data,
    themeExhibitions: res[3].data
  };
};

// 获取我的页面数据
export const getProfileData = async () => {
  const res = await axios.get(`${jsonServerUrl}/menuItems`);
  return res.data;
};

import { request } from "./request.js";
export const getHotList = () => request('/hotList', 'GET');
