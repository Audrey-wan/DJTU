package com.itbaizhan.bean;


//分类

public class Fenlei {

	private int id;//主键
	
	private String fname;//分类名称

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	


	
	
	
}
